PLEASE READ THIS BEFORE SUBMITTING A NEW ISSUE.

ARE YOU ASKING FOR HELP? Please use Stack Overflow tag d3.js and include a link to a live, minimal example, preferably on bl.ocks.org. If you have a question, consider the d3-js Google Group or the d3-js Slack.

For more: https://gist.github.com/mbostock/7f063e44c57ecb5828dd5643e61f92d3

ARE YOU REPORTING AN ISSUE? Please file an issue on the relevant D3 module, not here; see https://github.com/d3. Please isolate the specific methods that exhibit unexpected behavior and precisely describe how your expectations were not met.

For more: https://gist.github.com/mbostock/370b737ce71bed0749e103b01ce1bfaf
